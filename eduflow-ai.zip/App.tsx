
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Timer } from './components/Timer';
import { AIRecommendations } from './components/AIRecommendations';
import { Analytics } from './components/Analytics';
import { Rewards } from './components/Rewards';
import { View, StudySession, UserStats } from './types';
import { MOCK_SESSIONS } from './constants';
import { Bell, Search, User, Zap } from 'lucide-react';

const INITIAL_STATS: UserStats = {
  points: 450,
  streak: 12,
  level: 1,
  unlockedBadges: ['first_session'],
  lastUpdateDate: new Date().toISOString().split('T')[0]
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [sessions, setSessions] = useState<StudySession[]>(MOCK_SESSIONS);
  const [stats, setStats] = useState<UserStats>(INITIAL_STATS);
  const [showLevelUp, setShowLevelUp] = useState(false);

  // Persistence
  useEffect(() => {
    const savedSessions = localStorage.getItem('eduflow_sessions');
    if (savedSessions) setSessions(JSON.parse(savedSessions));

    const savedStats = localStorage.getItem('eduflow_stats');
    if (savedStats) setStats(JSON.parse(savedStats));
  }, []);

  useEffect(() => {
    localStorage.setItem('eduflow_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('eduflow_stats', JSON.stringify(stats));
  }, [stats]);

  const checkBadgeUnlocks = (newStats: UserStats, newSessions: StudySession[]) => {
    const newlyUnlocked: string[] = [...newStats.unlockedBadges];
    
    // Point Collector
    if (newStats.points >= 1000 && !newlyUnlocked.includes('point_collector')) {
      newlyUnlocked.push('point_collector');
    }
    
    // Subject Master (5 sessions in one subject)
    // For demo, we just check if total completed is > 5
    if (newSessions.filter(s => s.completed).length >= 5 && !newlyUnlocked.includes('subject_master')) {
      newlyUnlocked.push('subject_master');
    }

    return newlyUnlocked;
  };

  const toggleSession = (id: string) => {
    setSessions(prev => {
      const updated = prev.map(s => s.id === id ? { ...s, completed: !s.completed } : s);
      const session = updated.find(s => s.id === id);
      
      if (session && session.completed) {
        // Award points on completion
        setStats(prevStats => {
          const newPoints = prevStats.points + 50;
          const currentLevelThreshold = prevStats.level * 500;
          let newLevel = prevStats.level;
          
          if (newPoints >= currentLevelThreshold) {
            newLevel += 1;
            setShowLevelUp(true);
            setTimeout(() => setShowLevelUp(false), 3000);
          }

          const updatedStats = {
            ...prevStats,
            points: newPoints,
            level: newLevel,
          };

          const finalBadges = checkBadgeUnlocks(updatedStats, updated);
          return { ...updatedStats, unlockedBadges: finalBadges };
        });
      }
      
      return updated;
    });
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard sessions={sessions} stats={stats} onToggleSession={toggleSession} />;
      case 'focus':
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <header className="mb-12 text-center">
              <h1 className="text-3xl font-bold text-slate-900">Deep Work Session</h1>
              <p className="text-slate-500 mt-2">Silence notifications and immerse yourself in study.</p>
            </header>
            <Timer />
          </div>
        );
      case 'ai':
        return <AIRecommendations />;
      case 'analytics':
        return <Analytics />;
      case 'rewards':
        return <Rewards stats={stats} />;
      case 'schedule':
        return (
          <div className="bg-white p-8 rounded-3xl border border-slate-200 notion-shadow min-h-[400px] flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 mb-4">
              <Search size={32} />
            </div>
            <h2 className="text-xl font-bold text-slate-800">Advanced Schedule View</h2>
            <p className="text-slate-500 max-w-sm mt-2">The full calendar integration is coming soon in the v2 update. Use the dashboard to manage today's blocks.</p>
          </div>
        );
      default:
        return <Dashboard sessions={sessions} stats={stats} onToggleSession={toggleSession} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 ml-64 p-8 lg:p-12 relative">
        {showLevelUp && (
          <div className="fixed top-8 left-1/2 -translate-x-1/2 z-50 bg-blue-600 text-white px-8 py-4 rounded-3xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-top-12 duration-500">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
              <Zap size={24} className="fill-current" />
            </div>
            <div>
              <div className="font-bold text-lg">Level Up!</div>
              <div className="text-blue-100 text-sm">You've reached Level {stats.level}!</div>
            </div>
          </div>
        )}

        <header className="flex items-center justify-between mb-10">
          <div className="relative w-96 max-w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search subjects, achievements, or tasks..." 
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            />
          </div>
          
          <div className="flex items-center gap-6">
            <button className="relative p-2 text-slate-500 hover:text-slate-700 transition-colors">
              <Bell size={22} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-3 pl-6 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-bold text-slate-800 leading-none">Alex Johnson</div>
                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Level {stats.level} Scholar</div>
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden ring-2 ring-white">
                <img src="https://picsum.photos/seed/alex/100/100" alt="Avatar" />
              </div>
            </div>
          </div>
        </header>

        {renderView()}
      </main>
    </div>
  );
};

export default App;
