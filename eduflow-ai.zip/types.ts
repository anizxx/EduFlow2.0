
export interface StudySession {
  id: string;
  title: string;
  subject: string;
  startTime: string;
  endTime: string;
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  unlocked: boolean;
}

export interface UserStats {
  points: number;
  streak: number;
  level: number;
  unlockedBadges: string[];
  lastUpdateDate: string;
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export interface PerformanceMetric {
  day: string;
  hours: number;
  focus: number;
}

export interface AIRecommendation {
  subject: string;
  reason: string;
  tips: string[];
}

export type View = 'dashboard' | 'schedule' | 'focus' | 'ai' | 'analytics' | 'rewards';
