
import React from 'react';
import { NAVIGATION } from '../constants';
import { View } from '../types';
import { GraduationCap } from 'lucide-react';

interface SidebarProps {
  currentView: View;
  onViewChange: (view: View) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange }) => {
  return (
    <div className="w-64 h-full bg-white border-r border-slate-200 flex flex-col fixed left-0 top-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
          <GraduationCap size={24} />
        </div>
        <span className="font-bold text-xl text-slate-800 tracking-tight">EduFlow</span>
      </div>

      <nav className="flex-1 px-4 mt-4">
        <div className="space-y-1">
          {NAVIGATION.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-200 ${
                currentView === item.id
                  ? 'bg-blue-50 text-blue-600 font-medium'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-4 text-white">
          <h4 className="text-sm font-semibold mb-1">EduFlow Pro</h4>
          <p className="text-xs text-indigo-100 mb-3">Get advanced insights & unlimited AI tips.</p>
          <button className="w-full bg-white/20 hover:bg-white/30 py-1.5 rounded-lg text-xs font-medium transition-colors">
            Upgrade Now
          </button>
        </div>
      </div>
    </div>
  );
};
