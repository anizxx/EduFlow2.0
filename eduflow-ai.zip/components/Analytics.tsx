
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, AreaChart, Area 
} from 'recharts';
import { MOCK_CHART_DATA } from '../constants';
import { Calendar, Target, Zap } from 'lucide-react';

export const Analytics: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Performance Insights</h1>
        <p className="text-slate-500 mt-1">Visualize your study patterns and academic growth over time.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 notion-shadow">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-800">Study Hours / Week</h3>
            <div className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md">AVG: 4.4h</div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MOCK_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="hours" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 notion-shadow">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-800">Focus Score Trend</h3>
            <div className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">+12% vs last week</div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorFocus" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Area type="monotone" dataKey="focus" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorFocus)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 text-white p-6 rounded-3xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-slate-800 rounded-xl text-blue-400">
              <Calendar size={20} />
            </div>
            <span className="text-sm font-medium text-slate-400">Best Study Day</span>
          </div>
          <div className="text-2xl font-bold">Friday</div>
          <div className="text-xs text-slate-500 mt-1">Average of 7 hours logged</div>
        </div>

        <div className="bg-slate-900 text-white p-6 rounded-3xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-slate-800 rounded-xl text-emerald-400">
              <Zap size={20} />
            </div>
            <span className="text-sm font-medium text-slate-400">Peak Performance</span>
          </div>
          <div className="text-2xl font-bold">9:00 AM - 11:30 AM</div>
          <div className="text-xs text-slate-500 mt-1">Focus levels peak during mornings</div>
        </div>

        <div className="bg-slate-900 text-white p-6 rounded-3xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-slate-800 rounded-xl text-amber-400">
              <Target size={20} />
            </div>
            <span className="text-sm font-medium text-slate-400">Monthly Target</span>
          </div>
          <div className="text-2xl font-bold">120 / 150 Hours</div>
          <div className="text-xs text-slate-500 mt-1">80% of goal achieved</div>
        </div>
      </div>
    </div>
  );
};
