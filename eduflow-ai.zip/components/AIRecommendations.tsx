
import React, { useState } from 'react';
import { getStudyRecommendations } from '../services/gemini';
import { AIRecommendation } from '../types';
import { Sparkles, BrainCircuit, Lightbulb, Loader2, Send } from 'lucide-react';

export const AIRecommendations: React.FC = () => {
  const [subjects, setSubjects] = useState('');
  const [goals, setGoals] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<AIRecommendation | null>(null);

  const handleGenerate = async () => {
    if (!subjects || !goals) return;
    setLoading(true);
    const res = await getStudyRecommendations(subjects.split(','), goals);
    setRecommendation(res);
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-xs font-bold uppercase tracking-wider mb-4">
          <Sparkles size={14} /> AI Study Assistant
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Personalized Learning Roadmap</h1>
        <p className="text-slate-500 mt-2">Let Gemini analyze your curriculum and goals to find your optimal focus areas.</p>
      </header>

      <div className="bg-white rounded-3xl border border-slate-200 notion-shadow p-8">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">What subjects are you studying?</label>
            <input 
              type="text" 
              placeholder="e.g., Mathematics, Organic Chemistry, Microeconomics"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all"
              value={subjects}
              onChange={(e) => setSubjects(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">What are your current academic goals?</label>
            <textarea 
              placeholder="e.g., Prepare for the biology final exam next week, improve understanding of calculus derivatives"
              rows={3}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all resize-none"
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
            />
          </div>
          <button 
            onClick={handleGenerate}
            disabled={loading || !subjects || !goals}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all shadow-lg shadow-blue-200"
          >
            {loading ? <Loader2 className="animate-spin" /> : <BrainCircuit size={20} />}
            {loading ? 'Analyzing your profile...' : 'Generate AI Study Plan'}
          </button>
        </div>
      </div>

      {recommendation && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in zoom-in-95 duration-500">
          <div className="bg-white p-8 rounded-3xl border border-blue-100 shadow-xl shadow-blue-50">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center font-bold text-xl">
                {recommendation.subject[0]}
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">{recommendation.subject}</h3>
                <p className="text-blue-600 text-sm font-medium">Top Priority Recommendation</p>
              </div>
            </div>
            <div className="p-4 bg-blue-50/50 rounded-2xl">
              <p className="text-slate-700 leading-relaxed text-sm">
                <span className="font-bold text-blue-800">Why this first?</span> {recommendation.reason}
              </p>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 notion-shadow">
            <div className="flex items-center gap-3 mb-6">
              <Lightbulb className="text-amber-500" />
              <h3 className="text-lg font-bold text-slate-900">Recommended Strategies</h3>
            </div>
            <ul className="space-y-4">
              {recommendation.tips.map((tip, idx) => (
                <li key={idx} className="flex gap-4">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">
                    {idx + 1}
                  </span>
                  <p className="text-slate-600 text-sm leading-snug">{tip}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
