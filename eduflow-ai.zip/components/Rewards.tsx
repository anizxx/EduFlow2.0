
import React from 'react';
import { UserStats, Badge } from '../types';
import { BADGE_DEFINITIONS } from '../constants';
import { Trophy, Award, Zap, Star, BookOpen, Anchor, Lock, CheckCircle2 } from 'lucide-react';

interface RewardsProps {
  stats: UserStats;
}

const IconMap: Record<string, any> = {
  Anchor, Zap, Star, BookOpen, Award, Trophy
};

export const Rewards: React.FC<RewardsProps> = ({ stats }) => {
  const pointsToNextLevel = (stats.level * 500) - (stats.points % (stats.level * 500));
  const levelProgress = (stats.points % (stats.level * 500)) / (stats.level * 500) * 100;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Achievements</h1>
          <p className="text-slate-500 mt-1">Level up your productivity and collect rare badges.</p>
        </div>
        <div className="bg-white px-6 py-3 rounded-2xl border border-slate-200 notion-shadow flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Current Rank</div>
            <div className="text-lg font-bold text-blue-600">Level {stats.level} Scholar</div>
          </div>
          <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center font-bold text-xl">
            {stats.level}
          </div>
        </div>
      </header>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 notion-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-slate-800">Level Progress</h3>
          <span className="text-sm text-slate-500">{pointsToNextLevel} points to Level {stats.level + 1}</span>
        </div>
        <div className="relative w-full h-4 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-1000"
            style={{ width: `${levelProgress}%` }}
          />
        </div>
        <div className="mt-4 flex justify-between text-xs font-bold text-slate-400 uppercase tracking-tighter">
          <span>Level {stats.level}</span>
          <span>{stats.points} Total XP</span>
          <span>Level {stats.level + 1}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {BADGE_DEFINITIONS.map((badgeDef) => {
          const isUnlocked = stats.unlockedBadges.includes(badgeDef.id);
          const Icon = IconMap[badgeDef.icon] || Award;
          
          return (
            <div 
              key={badgeDef.id}
              className={`p-6 rounded-3xl border transition-all duration-300 ${
                isUnlocked 
                  ? 'bg-white border-slate-200 notion-shadow' 
                  : 'bg-slate-50 border-slate-100 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg ${
                  isUnlocked ? badgeDef.color : 'bg-slate-300'
                }`}>
                  <Icon size={28} />
                </div>
                {isUnlocked ? (
                  <div className="bg-emerald-100 text-emerald-600 p-1.5 rounded-full">
                    <CheckCircle2 size={16} />
                  </div>
                ) : (
                  <div className="bg-slate-200 text-slate-400 p-1.5 rounded-full">
                    <Lock size={16} />
                  </div>
                )}
              </div>
              <h3 className={`font-bold text-lg ${isUnlocked ? 'text-slate-800' : 'text-slate-400'}`}>
                {badgeDef.name}
              </h3>
              <p className="text-slate-500 text-sm mt-1 leading-relaxed">
                {badgeDef.description}
              </p>
              {!isUnlocked && (
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <div className="w-full bg-slate-200 h-1 rounded-full">
                    <div className="bg-slate-300 h-full rounded-full w-[25%]"></div>
                  </div>
                  <div className="text-[10px] font-bold text-slate-400 mt-2 uppercase">Progress: 25%</div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
