
import React from 'react';
import { StudySession, UserStats } from '../types';
import { CheckCircle2, Circle, Clock, Flame, Target, Trophy, Star } from 'lucide-react';

interface DashboardProps {
  sessions: StudySession[];
  stats: UserStats;
  onToggleSession: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ sessions, stats, onToggleSession }) => {
  const completed = sessions.filter(s => s.completed).length;
  const total = sessions.length;
  const progress = total > 0 ? (completed / total) * 100 : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Welcome back, Alex! 👋</h1>
          <p className="text-slate-500 mt-1">You have {total - completed} study blocks remaining for today.</p>
        </div>
        <div className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl shadow-lg shadow-blue-200">
          <Star size={18} className="fill-current" />
          <span className="font-bold">{stats.points} XP</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 notion-shadow flex items-center gap-4 group hover:border-orange-200 transition-colors">
          <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Flame size={24} />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">{stats.streak} Days</div>
            <div className="text-sm text-slate-500">Study Streak</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 notion-shadow flex items-center gap-4 group hover:border-blue-200 transition-colors">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Target size={24} />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">{Math.round(progress)}%</div>
            <div className="text-sm text-slate-500">Daily Goal</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 notion-shadow flex items-center gap-4 group hover:border-emerald-200 transition-colors">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Trophy size={24} />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-800">Level {stats.level}</div>
            <div className="text-sm text-slate-500">Academic Rank</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-800">Today's Schedule</h2>
            <button className="text-blue-600 text-sm font-medium hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {sessions.map((session) => (
              <div 
                key={session.id}
                className={`group flex items-center justify-between p-4 bg-white border rounded-xl transition-all ${
                  session.completed ? 'border-emerald-100 bg-emerald-50/30' : 'border-slate-200 hover:border-blue-200 shadow-sm'
                }`}
              >
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => onToggleSession(session.id)}
                    className={`transition-all hover:scale-110 ${session.completed ? 'text-emerald-500' : 'text-slate-300 group-hover:text-blue-400'}`}
                  >
                    {session.completed ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                  </button>
                  <div>
                    <h3 className={`font-semibold ${session.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                      {session.title}
                    </h3>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                      <span className="flex items-center gap-1"><Clock size={12}/> {session.startTime} - {session.endTime}</span>
                      <span className={`px-2 py-0.5 rounded-full ${
                        session.priority === 'High' ? 'bg-red-50 text-red-600' : 
                        session.priority === 'Medium' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'
                      }`}>
                        {session.priority}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {!session.completed && (
                     <button className="opacity-0 group-hover:opacity-100 bg-slate-100 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 transition-all hover:bg-slate-200">
                      Focus Mode
                    </button>
                  )}
                  {session.completed && (
                    <span className="text-emerald-600 text-xs font-bold">+50 XP</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
           <div className="bg-white p-6 rounded-2xl border border-slate-200 notion-shadow">
            <h2 className="text-lg font-bold text-slate-800 mb-4">Productivity Score</h2>
            <div className="relative w-full h-4 bg-slate-100 rounded-full overflow-hidden">
               <div 
                className="absolute top-0 left-0 h-full bg-blue-500 transition-all duration-1000"
                style={{ width: `${progress}%` }}
               />
            </div>
            <div className="mt-4 flex justify-between text-sm">
              <span className="text-slate-500">Progress</span>
              <span className="font-bold text-slate-800">{Math.round(progress)}%</span>
            </div>
            <p className="text-xs text-slate-400 mt-4 leading-relaxed">
              Based on your study habits today, you are performing better than 75% of your typical sessions. Keep it up!
            </p>
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-6 rounded-2xl text-white notion-shadow relative overflow-hidden">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
            <h3 className="font-bold text-lg mb-2 flex items-center gap-2">
              <Trophy size={18} /> Daily Quest
            </h3>
            <div className="text-xl font-bold mb-1">Night Owl</div>
            <p className="text-indigo-100 text-xs mb-4">Complete one more session after 8:00 PM to earn a rare badge!</p>
            <div className="bg-white/20 h-2 rounded-full">
              <div className="bg-white h-full rounded-full w-[60%]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
