
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain } from 'lucide-react';

export const Timer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  // Use ReturnType<typeof setInterval> instead of NodeJS.Timeout to fix browser-environment TS error
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleComplete = () => {
    setIsActive(false);
    if (mode === 'work') {
      alert('Time for a break!');
      setMode('break');
      setTimeLeft(5 * 60);
    } else {
      alert('Back to work!');
      setMode('work');
      setTimeLeft(25 * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'work' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'work' ? (timeLeft / (25 * 60)) * 100 : (timeLeft / (5 * 60)) * 100;

  return (
    <div className="max-w-md mx-auto bg-white rounded-3xl p-10 border border-slate-200 notion-shadow text-center">
      <div className="flex justify-center gap-4 mb-8">
        <button 
          onClick={() => { setMode('work'); setTimeLeft(25 * 60); setIsActive(false); }}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${mode === 'work' ? 'bg-blue-100 text-blue-600' : 'text-slate-400 hover:bg-slate-50'}`}
        >
          <Brain size={16} /> Work
        </button>
        <button 
          onClick={() => { setMode('break'); setTimeLeft(5 * 60); setIsActive(false); }}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${mode === 'break' ? 'bg-emerald-100 text-emerald-600' : 'text-slate-400 hover:bg-slate-50'}`}
        >
          <Coffee size={16} /> Break
        </button>
      </div>

      <div className="relative inline-flex items-center justify-center mb-8">
        <svg className="w-64 h-64 -rotate-90">
          <circle 
            cx="128" cy="128" r="120" 
            stroke="currentColor" strokeWidth="8" 
            fill="transparent" className="text-slate-100" 
          />
          <circle 
            cx="128" cy="128" r="120" 
            stroke="currentColor" strokeWidth="8" 
            fill="transparent" className={`${mode === 'work' ? 'text-blue-600' : 'text-emerald-500'} transition-all duration-1000`}
            strokeDasharray={754}
            strokeDashoffset={754 * (progress / 100)}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute text-6xl font-black text-slate-800 tracking-tighter tabular-nums">
          {formatTime(timeLeft)}
        </div>
      </div>

      <div className="flex items-center justify-center gap-4">
        <button 
          onClick={resetTimer}
          className="w-12 h-12 flex items-center justify-center rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
        >
          <RotateCcw size={20} />
        </button>
        <button 
          onClick={toggleTimer}
          className={`w-16 h-16 flex items-center justify-center rounded-2xl shadow-lg transition-transform hover:scale-105 ${isActive ? 'bg-slate-800 text-white' : 'bg-blue-600 text-white'}`}
        >
          {isActive ? <Pause size={32} /> : <Play size={32} fill="currentColor" className="ml-1" />}
        </button>
        <div className="w-12 h-12" /> {/* Spacer */}
      </div>

      <p className="mt-8 text-slate-500 text-sm">
        {mode === 'work' ? "Stay focused on your current task." : "Great job! Take a short breather."}
      </p>
    </div>
  );
};
