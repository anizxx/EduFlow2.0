
import React from 'react';
import { 
  LayoutDashboard, 
  Calendar, 
  Clock, 
  Sparkles, 
  BarChart3, 
  Trophy,
  Award,
  Zap,
  Star,
  BookOpen,
  Anchor
} from 'lucide-react';

export const COLORS = {
  primary: '#3b82f6',
  secondary: '#6366f1',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  background: '#f8fafc',
};

export const NAVIGATION = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'schedule', label: 'Schedule', icon: <Calendar size={20} /> },
  { id: 'focus', label: 'Focus Mode', icon: <Clock size={20} /> },
  { id: 'ai', label: 'AI Tutor', icon: <Sparkles size={20} /> },
  { id: 'analytics', label: 'Insights', icon: <BarChart3 size={20} /> },
  { id: 'rewards', label: 'Achievements', icon: <Trophy size={20} /> },
];

export const BADGE_DEFINITIONS = [
  { id: 'first_session', name: 'First Step', description: 'Completed your first study session', icon: 'Anchor', color: 'bg-blue-500' },
  { id: 'week_warrior', name: 'Week Warrior', description: 'Maintained a 7-day streak', icon: 'Zap', color: 'bg-orange-500' },
  { id: 'subject_master', name: 'Subject Master', description: 'Completed 5 sessions in one subject', icon: 'BookOpen', color: 'bg-purple-500' },
  { id: 'point_collector', name: 'Elite Learner', description: 'Reached 1,000 total points', icon: 'Star', color: 'bg-yellow-500' },
  { id: 'focus_king', name: 'Focus King', description: 'Completed a 60-minute deep work session', icon: 'Award', color: 'bg-emerald-500' },
];

export const MOCK_SESSIONS: any[] = [
  { id: '1', title: 'Advanced Calculus', subject: 'Math', startTime: '09:00', endTime: '10:30', completed: true, priority: 'High' },
  { id: '2', title: 'Cell Biology Review', subject: 'Biology', startTime: '11:00', endTime: '12:30', completed: false, priority: 'Medium' },
  { id: '3', title: 'Modern History', subject: 'History', startTime: '14:00', endTime: '15:30', completed: false, priority: 'Low' },
];

export const MOCK_CHART_DATA = [
  { day: 'Mon', hours: 4.5, focus: 85 },
  { day: 'Tue', hours: 6.2, focus: 70 },
  { day: 'Wed', hours: 3.8, focus: 90 },
  { day: 'Thu', hours: 5.5, focus: 80 },
  { day: 'Fri', hours: 7.0, focus: 95 },
  { day: 'Sat', hours: 2.0, focus: 60 },
  { day: 'Sun', hours: 1.5, focus: 40 },
];
